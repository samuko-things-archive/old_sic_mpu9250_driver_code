…or create a new repository on the command line

echo "# arduino_matrix_vector_lab" >> README.md

git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/samuko-things/arduino_matrix_vector_lab.git
git push -u origin main