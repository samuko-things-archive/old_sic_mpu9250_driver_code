# imu_madgwick_filter
madgwick filter arduino library based on the imu_tool madgwick code by CCNYRoboticsLab